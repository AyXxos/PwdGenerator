from random import randint
import pyperclip
mdp = []

for i in range(19):
    nb = randint(33, 125)
    nb = chr(nb)
    mdp.append(nb)

# Imprimer le mot de passe
print(''.join(mdp))

pyperclip.copy(''.join(mdp))